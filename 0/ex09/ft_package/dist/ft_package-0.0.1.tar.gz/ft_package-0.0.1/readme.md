# Example Package ft_package

Just a simple package to be installed via pip.
```
```

## Create package
python3 -m pip install --upgrade build
python3 -m build
```
